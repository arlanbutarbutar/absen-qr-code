# absen-qr-code
Sistem Presensi Menggunakan QR Code Pada Jurusan Teknik Elektro Di Politeknik Negeri Kupang Berbasis Web

Tujuan dari pembuatan sistem absensi dengan menggunakan QR Code dalam penelitian ini adalah:
1.	Menerapkan QR Code untuk sistem kehadiran/absensi mahasiswa pada pada Jurusan Teknik Elektro.
2.	Membuat atau merancang sistem absensi mahasiswa berbasis web pada Jurusan Teknik Elektro.

Manfaat dari pembuatan sistem absensi dengan menggunakan QR Code dalam penelitian ini adalah:
1.	Untuk meminimalisir pelanggaran aturan berupa manipulasi data presensi yang dilakukan mahasiswa.
2.	Memberikan efisiensi waktu dalam proses pencatatan serta penghitungan rekapitulasi presensi mahasiswa karena bersifat otomatisasi
