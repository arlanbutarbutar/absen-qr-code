<?php
$conn=mysqli_connect("localhost","gaslvldx_tugasakhir","Z0q,fDg@XVRH","gaslvldx_berty");
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
