<nav class="navbar navbar-expand-lg custom_nav-container">
  <a class="navbar-brand" href="./">
    <img src="assets/images/logo.png" alt="" style="width: 70px;" />
  </a>
  <div class="navbar-collapse" id="">
    <ul class="navbar-nav justify-content-between ">
      <div class="User_option">
        <li class="">
          <a class="mr-4" href="./">
            Beranda
          </a>
          <a class="mr-4" href="auth/masuk">
            Masuk
          </a>
        </li>
      </div>
    </ul>

    <div class="custom_menu-btn">
      <button onclick="openNav()">
        <span class="s-1">

        </span>
        <span class="s-2">

        </span>
        <span class="s-3">

        </span>
      </button>
    </div>
    <div id="myNav" class="overlay">
      <div class="overlay-content">
        <a href="./">Beranda</a>
        <a href="auth/masuk">Masuk</a>
      </div>
    </div>
  </div>
</nav>